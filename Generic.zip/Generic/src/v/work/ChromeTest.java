package v.work;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ChromeTest {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", ".\\exefiles\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		
		driver.navigate().to("http://localhost/TOS11/");
		driver.getTitle();
		driver.getCurrentUrl();
		
		driver.findElement(By.id("txtusername")).sendKeys("Administrator");
		driver.findElement(By.id("txtpassword")).sendKeys("Savior@1");
		driver.findElement(By.id("btnLogin")).click();
		
		System.out.println("login success");
		
	}

}
