package v.work;

public class Count_Characters {
	public static void main(String[] args) {
		String word="";
		int lenght = word.length();
		System.out.println(lenght);
	}

}
