package v.work;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ReadExcelData {
	
	static final String filepath=".\\test-data\\TOS10_test-Data.xls";
	static double value=0;
	
	public static double readDataDemo(String sheetName, int rNum, int cNum)
	{
	  
	try {
		Workbook wb = WorkbookFactory.create(new FileInputStream(new File(filepath)));
		value=wb.getSheet(sheetName).getRow(rNum).getCell(cNum).getNumericCellValue();
	} catch (EncryptedDocumentException | InvalidFormatException | IOException e) {
		
		e.printStackTrace();
	}

	return value;
	}
	
}
