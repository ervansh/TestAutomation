package v.work;

import java.awt.List;
import java.io.File;
import java.util.Arrays;

import org.apache.commons.logging.Log;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.TestRunner;
import org.testng.internal.DynamicGraph.Status;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.relevantcodes.extentreports.NetworkMode;

public class Extentreporttest {
	
	
	    private static ExtentReports extent;

	    public static void main(String[] args) {
	        extent = new ExtentReports("D:\\Vanshraj.Singh\\Reports\\TOS Standard\\ExtentReports\\demo.html", NetworkMode.OFFLINE);
	        String xmlfilepath = ".\\test_data\\extent-config.xml";
             extent.loadConfig(new File(xmlfilepath));
	        // creates a toggle for the given test, adds all log events under it    
	        ExtentTest test = extent.startTest("My First Test", "Sample description").assignCategory("regression", "njdnk", "jjjdj");

	        // log(LogStatus, details)
	        test.log(LogStatus.INFO, "This step shows usage of log(logStatus, details)");
	        Exception e;
	        // report with snapshot
	        String img = test.addScreenCapture("img-path");
	        test.log(LogStatus.INFO, "Image", "Image example: " + img);
	        
	        test.log(LogStatus.INFO, "HTML", "Usage: BOLD TEXT");
	        
	        ExtentTest parent = extent.startTest("Parent");

	        ExtentTest child1 = extent.startTest("Child 1");
	        child1.log(LogStatus.INFO, "Info");

	        ExtentTest child2 = extent.startTest("Child 2");
	        child2.log(LogStatus.PASS, "Pass");

	        parent
	            .appendChild(child1)
	            .appendChild(child2);
	            
	        extent.endTest(parent); //  to add child
	        
	        extent.setTestRunnerOutput("hello");//................to set logs in report
	        
	        

	        LogStatus rs = test.getRunStatus();
	        test.assignCategory("smoke");  //..........................to add category in report
	        // end test
	        extent.endTest(test);
	        
	        // calling flush writes everything to the log file
	        extent.flush();
	    }
	


}
