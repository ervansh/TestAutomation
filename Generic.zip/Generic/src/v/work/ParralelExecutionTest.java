package v.work;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterMethod;

public class ParralelExecutionTest {
  
  @BeforeMethod
  @Parameters("browser")
  public void beforeMethod(String bn) {
	  if(bn.equalsIgnoreCase("firefox"))
	  {
		  WebDriver driver= new FirefoxDriver();
		  driver.manage().window().maximize();
		  System.out.println("firefox launched");
	  }
	  
	  else if(bn.equalsIgnoreCase("ie"))
	  {
		  System.setProperty("webdriver.ie.driver", ".\\exefiles\\IEDriverServer.exe");
		  WebDriver driver= new InternetExplorerDriver();
		  driver.manage().window().maximize();
		  System.out.println("ie launched");
	  }
  }

  @AfterMethod
  public void afterMethod() {
	  
	  System.out.println("browser closed");
	  
  }

}
