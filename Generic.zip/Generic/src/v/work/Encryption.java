package v.work;

import java.util.Base64.Encoder;

import org.apache.commons.codec.binary.Base64;
import org.openqa.selenium.interactions.internal.BaseAction;

public class Encryption {

	public static void main(String[] args) {
		en1();
		
	}

	public static void en1(){
		byte[] encodedBytes = Base64.encodeBase64("vanshraj".getBytes());
		System.out.println("encodedBytes "+ new String(encodedBytes));

		byte[] decodedBytes = Base64.decodeBase64(encodedBytes);
		System.out.println("decodedBytes "+ new String(decodedBytes));
	}
	
	
}
