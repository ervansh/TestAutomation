package dataProviderwithexcel;

import org.testng.annotations.Test;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeMethod;

public class DemoTest {
	WebDriver driver;
	
	@BeforeMethod
	  public void beforeMethod() {
		  driver=new FirefoxDriver();
		  driver.get("http://localhost/shilpa/");
		  driver.manage().window().maximize();
	  }

  @Test
  public void f() throws InterruptedException {
	 WebElement username = driver.findElement(By.id("txtusername"));
	 username.sendKeys("Administrator");
	 driver.findElement(By.id("txtpassword")).sendKeys("savior@1");
	 driver.findElement(By.id("lnklogin")).click();
	 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	 
	 Thread.sleep(2000);
	 driver.findElement(By.xpath("//a[text()='Attendance report']")).click();
	 driver.findElement(By.xpath("//a[text()='Monthly Report']")).click();
	 driver.findElement(By.id("ctl00_ContentPlaceHolder1_cmdSelect")).click();
	 
	 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	 
	 Set<String> windowId = driver.getWindowHandles();
	 Iterator<String> it = windowId.iterator();
	String parentid = it.next();
	String childId = it.next();
	driver.switchTo().window(childId);
	
	 WebElement companydropdown = driver.findElement(By.id("lstCompany"));
	 Select sel = new Select(companydropdown);
	 sel.selectByVisibleText("STJ01 STJ Electronics Pvt Ltd");
	 
	 driver.findElement(By.id("cmdOK")).click();
	 driver.switchTo().window(parentid);
	 driver.findElement(By.id("ctl00_ContentPlaceHolder1_Button1")).click();
  }
  
}
