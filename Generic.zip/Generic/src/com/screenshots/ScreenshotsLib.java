package com.screenshots;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.support.events.EventFiringWebDriver;

public class ScreenshotsLib {

	public void getScreenShot(WebDriver driver, String fileName) {
		EventFiringWebDriver efw = new EventFiringWebDriver(driver);
		try {
			FileUtils.copyFile(efw.getScreenshotAs(OutputType.FILE), new File(".\\screenshots\\" + fileName + ".png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @description RemoteWebDriver does not implement the TakesScreenshot class if
	 *              the driver have the Capabilities to take a screenshot then
	 *              Augmenter will add the TakesScreenshot methods to the instance
	 */
	public static void takeScreenshot(WebDriver driver, String fileName) {
		//WebDriver augmenteddriver = new Augmenter().augment(driver);
		//File screenshot = ((TakesScreenshot) augmenteddriver).getScreenshotAs(OutputType.FILE);
		File screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(screenshot, new File(".\\screenshots\\" + fileName + ".png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
