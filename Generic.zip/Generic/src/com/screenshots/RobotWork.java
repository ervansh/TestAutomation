package com.screenshots;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class RobotWork {
	
	
	public static void robotScreen(String testStepName){
		Robot robot=null;
	try {
		robot = new Robot();
	} catch (AWTException e) {
		e.printStackTrace();
	}
	BufferedImage img = robot.createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
	try {
		String y = System.getProperty("user.dir");
		System.out.println(y);
        String path=System.getProperty("user.dir")+"/robot-output/"+testStepName+System.currentTimeMillis()+".png";
        File file = new File(path);
        //File file = new File(".\\robot-output\\screenshot.png");
		ImageIO.write(img, "png", file);
	    } catch (IOException e) {
		e.printStackTrace();
	 }
	
	}
	
	
}

















