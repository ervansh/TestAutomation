package com.dataUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ExcelUtility {

	public static FileInputStream fis;
	public static Workbook wb;
	private static final String filepath = "src/main/resources/com/data/testdata.xlsx";

	public static Object[][] getTestData(String sheetname) {
		System.out.println(sheetname);
		try {
			fis=new FileInputStream(new File(filepath));
			wb = WorkbookFactory.create(fis);

		} catch (EncryptedDocumentException | InvalidFormatException | IOException e) {
			e.printStackTrace();
		}
		finally {
			try {
				fis.close();
				wb.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		Sheet sheet = wb.getSheet(sheetname);
		Object[][] data = new Object[sheet.getLastRowNum()][sheet.getRow(0).getLastCellNum()];
		System.out.println(data+" data");
		for (int i = 0; i < sheet.getLastRowNum(); i++) {
			for (int j = 0; j < sheet.getRow(i).getLastCellNum(); j++) {
				data[i][j] = sheet.getRow(i + 1).getCell(j).toString();
			}
		}
		return data;
		
	}
	
	@DataProvider
	public Object[][] getTosData() {
		Object[][] data = getTestData("Sheet1");
		return data;
	}

@Test(dataProvider="getTosData")
public void testdata(String a, String b, String c, String d) {
	System.out.println(a);
	System.out.println(b);
	System.out.println(c);
	System.out.println(d);
	
}
}




