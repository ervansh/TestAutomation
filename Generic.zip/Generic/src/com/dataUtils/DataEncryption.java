package com.dataUtils;


import org.apache.commons.codec.binary.Base64;

public class DataEncryption {

	public static String codeIT(String datatoencode)
	{
		byte[] codedbyte = Base64.encodeBase64(datatoencode.getBytes());
		return new String(codedbyte);
		
	}
	
	public static String decodeIt(String encodeddata) {
		byte[] decodedbytes = Base64.decodeBase64(encodeddata);
		return new String(decodedbytes);
	}
	
	public static void main(String[] args) {
		String key = PropertyValues.getPropertyValue("color");
		System.out.println(key);
		
		
		
		System.out.println(codeIT("color")+" encoded");
		
		//PropertyValues.writeProperty("color", "blue");
		
		System.out.println(decodeIt(key)+" decoded data");
	}
}
