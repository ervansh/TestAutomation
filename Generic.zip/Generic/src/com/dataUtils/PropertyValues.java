package com.dataUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * @author vanshraj.singh
 */
public class PropertyValues {
	private static final String filepath = "src/main/resources/com/data/demodata.properties";
	public static Properties prop= new Properties();
	public static FileInputStream fis;
	public static FileOutputStream fos;
	public static String getPropertyValue(String key) {
		
		try {
			fis=new FileInputStream(new File(filepath));
			prop.load(fis);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return prop.getProperty(key);
	}
	
	public static void writeProperty(String key, String value) {
		prop.setProperty(key, value);
		
		try {
			fos=new FileOutputStream(new File(filepath));
			prop.store(fos, null);
			fos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		System.out.println(getPropertyValue("Writer")+" read test");
		writeProperty("Message", "Hello World...");
		System.out.println(getPropertyValue("Message")+" write test");
	}
}
