package handlingBrowserEvents;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class DemoClass {

	public static void main(String[] args) {
		System.setProperty("webdriver.gecko.driver", "D:\\Software\\drivers\\geckodriver-v0.21.0-win64\\geckodriver.exe");
		WebDriver d=new FirefoxDriver();
	}
}
