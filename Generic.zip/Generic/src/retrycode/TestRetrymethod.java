package retrycode;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners({retrycode.AnnotationTransformer.class})
public class TestRetrymethod {

	@Test
	public void A() {
		Assert.assertTrue(true);
	}
	
	@Test()
	public void B() {
		Assert.assertTrue(false);
	}
	
	@Test(dependsOnMethods= {"B"})
	public void C() {
		Assert.assertTrue(true);
	}

}
