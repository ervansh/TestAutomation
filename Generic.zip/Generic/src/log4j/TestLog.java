package log4j;


import org.apache.log4j.Logger;

public class TestLog {

	public static void main(String[] args) {
		System.setProperty("webdriver.gecko.driver", "./drivers/geckodriver.exe");
         Logger log = Logger.getLogger("selenium");
         log.info("hello");
	}
}
