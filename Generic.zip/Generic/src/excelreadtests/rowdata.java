package excelreadtests;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class rowdata {

	static String filepath = ".\\test-data\\xdata.xlsx";

	public static void main(String[] args) {
		rowdata.x2("sheet1", 1, 0);
	}

	public static void x2(String filename, int rownum, int celnum) {
		try {
			FileInputStream fis = new FileInputStream(new File(filepath));
			Workbook wb = WorkbookFactory.create(fis);

			Sheet sh = wb.getSheet("Sheet1");
			int lrn = sh.getLastRowNum();
			Row rw = sh.getRow(rownum);
			Cell cn = rw.getCell(celnum);

		} catch (IOException | EncryptedDocumentException | InvalidFormatException e) {
			e.getMessage();
		}
	}

}
