package excelreadtests;

import java.io.File;
import java.io.IOException;

import org.apache.poi.hssf.record.crypto.Biff8EncryptionKey;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.NPOIFSFileSystem;

public class test2 {

	
	
	public static void main(String[] args) throws IOException {
		String fname=".\\test-data\\xdata.xlsx";
		Biff8EncryptionKey.setCurrentUserPassword("pass");
		NPOIFSFileSystem fs = new NPOIFSFileSystem(new File(fname), true);
		HSSFWorkbook hwb = new HSSFWorkbook(fs.getRoot(), true);
		Biff8EncryptionKey.setCurrentUserPassword(null);

		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}









