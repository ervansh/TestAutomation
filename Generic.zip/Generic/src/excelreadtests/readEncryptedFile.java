package excelreadtests;

import java.io.File;
import java.io.IOException;
import java.security.GeneralSecurityException;

import org.apache.poi.hssf.record.crypto.Biff8EncryptionKey;
import org.apache.poi.poifs.crypt.Decryptor;
import org.apache.poi.poifs.crypt.EncryptionInfo;
import org.apache.poi.poifs.filesystem.NPOIFSFileSystem;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class readEncryptedFile {

	public static void main(String[] args) throws IOException, GeneralSecurityException {
		
		String filename=".\\test-data\\xdata.xlsx";
		
		
		String p = Biff8EncryptionKey.getCurrentUserPassword();
		System.out.println(p+" bjdb");
		
		NPOIFSFileSystem fs = new NPOIFSFileSystem(new File(filename));
		EncryptionInfo info = new EncryptionInfo(fs);
		Decryptor d = Decryptor.getInstance(info);
		if (d.verifyPassword("vansh")) {
		   XSSFWorkbook wb = new XSSFWorkbook(d.getDataStream(fs));
		   System.out.println("abc");
		} else {
		   // Password is wrong
		}
	}
}
