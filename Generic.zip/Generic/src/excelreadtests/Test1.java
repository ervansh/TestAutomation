package excelreadtests;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.annotations.Test;

public class Test1 {

	String filename = ".\\test-data\\xdata.xlsx";
	@Test
	public void xl() throws EncryptedDocumentException, InvalidFormatException, IOException {
		//String filename = ".\\test-data\\xdata.xlsx";

		try {
			File file = new File(filename);
			FileInputStream fis = new FileInputStream(file);
			Workbook workbook = WorkbookFactory.create(fis);
			Sheet sheet = workbook.getSheetAt(0);

			java.util.Iterator<Row> rows = sheet.rowIterator();
			while (rows.hasNext()) {
				Row row = rows.next();
				java.util.Iterator<Cell> cells = row.cellIterator();
				while (cells.hasNext()) {
					Cell cell = cells.next();

					CellType type = cell.getCellTypeEnum();
					if (type == CellType.STRING) {
						System.out.println("[" + cell.getRowIndex() + ", " + cell.getColumnIndex()
								+ "] = STRING; Value = " + cell.getRichStringCellValue().toString());
					} else if (type == CellType.NUMERIC) {
						if (DateUtil.isCellDateFormatted(cell)) {
							SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
							String date = sdf.format(cell.getDateCellValue());
							System.out.println("[" + cell.getRowIndex() + ", " + cell.getColumnIndex()
									+ "] = STRING; Value = " + date.toString());
						} else {

							System.out.println("[" + cell.getRowIndex() + ", " + cell.getColumnIndex()
									+ "] = NUMERIC; Value = " + cell.getNumericCellValue());
						}
					} else if (type == CellType.BOOLEAN) {
						System.out.println("[" + cell.getRowIndex() + ", " + cell.getColumnIndex()
								+ "] = BOOLEAN; Value = " + cell.getBooleanCellValue());
					} else if (type == CellType.BLANK) {
						System.out.println("[" + cell.getRowIndex() + ", " + cell.getColumnIndex() + "] = BLANK CELL");
					}
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	

}























