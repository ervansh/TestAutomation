package dbconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class DbmainMethod {

	public static void main(String[] args) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
		String databseurl = "jdbc:mysql://198.168.1.135:3306/shilpa";
		String username = "sa";
		String password = "savior@1";

		Class.forName("com.mysql.jdbc.Driver").newInstance();
		Connection connection = DriverManager.getConnection(databseurl, username, password);
		Statement statement = connection.createStatement();
		
		String query = "select * from tblemployee";
		ResultSet resultset = statement.executeQuery(query);
		while(resultset.next()){
			int paycode = resultset.getInt("paycode");
			System.out.println(paycode);
			String EmpName= resultset.getString(2);
			System.out.println(EmpName);
		}
	}

}
