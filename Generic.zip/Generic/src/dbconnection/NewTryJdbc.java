package dbconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class NewTryJdbc {
	public static void main(String[] args) throws InstantiationException, IllegalAccessException, ClassNotFoundException {
		System.out.println("Connecting...");
		Connection con=null;
		try{
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con=DriverManager.getConnection("jdbc:sqlserver://192.168.10.152:3307;databaseName=QAS_VS_TOS921_AUTOMATION;user=qasns;password=qas_ns@123;");
		if(con!=null){
			System.out.println("connection success");
		}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
	}

}
