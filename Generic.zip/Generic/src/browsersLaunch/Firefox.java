package browsersLaunch;

import java.io.File;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class Firefox {
	public static WebDriver driver;
	protected static ExtentReports extent;
	protected static ExtentTest test;
	static DesiredCapabilities capabilities;

	static final String DOWNLOADPATH = "";
	public static void main(String[] args) {
		System.setProperty("webdriver.gecko.driver", ".\\exefiles\\geckodriver.exe");
		capabilities = DesiredCapabilities.firefox();
		capabilities.setCapability("marionette", true);
		driver = new FirefoxDriver();
	}
	public FirefoxProfile FirefoxDriverProfile() {
		FirefoxProfile profile = new FirefoxProfile();

		profile.setPreference("browser.download.folderList", 2);
		profile.setPreference("browser.download.manager.showWhenStarting", false);
		profile.setPreference("browser.download.dir", DOWNLOADPATH);
		profile.setPreference("browser.helperApps.neverAsk.openFile",
				"text/csv,application/x-msexcel,application/excel,application/x-excel,application/vnd.ms-excel,image/png,image/jpeg,text/html,text/plain,application/msword,application/xml");
		profile.setPreference("browser.helperApps.neverAsk.saveToDisk",
				"text/csv,application/x-msexcel,application/excel,application/x-excel,application/vnd.ms-excel,image/png,image/jpeg,text/html,text/plain,application/msword,application/xml");
		profile.setPreference("browser.helperApps.alwaysAsk.force", false);
		profile.setPreference("browser.download.manager.alertOnEXEOpen", false);
		profile.setPreference("browser.download.manager.focusWhenStarting", false);
		profile.setPreference("browser.download.manager.useWindow", false);
		profile.setPreference("browser.download.manager.showAlertOnComplete", false);
		profile.setPreference("browser.download.manager.closeWhenDone", false);
		return profile;
	}

	public FirefoxBinary firefoxbinary() {
		File browserAppPath = null;
		if (Platform.getCurrent().is(Platform.WINDOWS)) {
			browserAppPath = new File("C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe");
			if (!browserAppPath.exists()) {
				browserAppPath = new File("C:\\Program Files\\Mozilla Firefox\\firefox.exe");
			}
		}
		FirefoxBinary ffb = new FirefoxBinary(browserAppPath);
		return ffb;
	}

}
