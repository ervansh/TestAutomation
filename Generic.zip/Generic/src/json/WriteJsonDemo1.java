package json;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;

import org.json.simple.JSONObject;

public class WriteJsonDemo1 {
	
	public static void main(String[] args) throws IOException {
		JSONObject jo = new JSONObject();
		jo.put("Color", "Red");
		jo.put("Book", "Let us c");
		jo.put("Laptop", "Dell");
		jo.put("Name", "John");
		jo.put("Mob", 94554192);
		
		HashMap<Object, Object> addmap = new HashMap<>();
		addmap.put("Hn", 120);
		addmap.put("city", "Delhi");
		addmap.put("Locality", "Okhla-2");
		addmap.put("Is Permanent add", true);
		
		jo.put("Address", addmap);
		
		jo.remove("Book");
		
		ArrayList<Object> al = new ArrayList<>();
		al.add("Java");
		al.add("C");
		al.add("C++");
		
		jo.put("Languages Known", al);
		
		String path = "src/main/java/json/demo1.json";
		PrintWriter pw = new PrintWriter(path);
		pw.write(jo.toJSONString());
		pw.flush();
		pw.close();
	}

}









