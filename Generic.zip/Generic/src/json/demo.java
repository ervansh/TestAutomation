package json;

public class demo {

	public static void chacha() {
		System.out.println("hi...");
		
		
		
		{
			System.out.println("hello...");
		}
	}
	
	
	public static void main(String[] args) {
		System.out.println("world...");
		chacha();
	}
}
