package json;

import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONValue;

public class JsonEncodingwithMap {
	
	public static void main(String args[]){    
		  HashMap obj = new HashMap();    
		  obj.put("name","sonoo");    
		  obj.put("age",new Integer(27));    
		  obj.put("salary",new Double(600000));  
		  
		  System.out.println(obj);
		  
		  
		  String jsonText = JSONValue.toJSONString(obj);  
		  System.out.print(jsonText);  
		}    

}
