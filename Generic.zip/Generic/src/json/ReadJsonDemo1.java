package json;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class ReadJsonDemo1 {
	
	public static void main(String[] args) throws IOException, ParseException {
		
		String file = "src/main/java/json/demo1.json";
		
		FileReader fr = new FileReader(file);
		
		Object jp = new JSONParser().parse(fr);
		JSONObject jo = (JSONObject)jp;
		
		String color = (String)jo.get("Color");
		System.out.println(color);
		
		Object mob = jo.get("Mob");
		System.out.println(mob);
		
		
		Object ad = jo.get("Address");
		System.out.println(ad);
		
		Map admap = (Map)ad;
		Set ades = admap.entrySet();
		System.out.println(ades);
		Set adks = admap.keySet();
		System.out.println(adks);
		for (Object object : adks) {
			System.out.println(admap.get(object));
		}
		
		Iterator itr = ades.iterator();
		while (itr.hasNext()) {
			itr.next();
		}
		
		Object kl = jo.get("Languages Known");
		System.out.println(kl);
		
		ArrayList alkl = (ArrayList)kl;
		Iterator alit = alkl.iterator();
		while(alit.hasNext()) {
			System.out.println(alit.next());
		}
	}

}











