package scripts;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.annotations.Test;

public class ExcelSheetTest {
	
	public static Object readxl(String SheetName) throws EncryptedDocumentException, InvalidFormatException, IOException{
		
		String filepath= ".\\test-data\\xdata.xlsx";
		File file = new File(filepath);
		FileInputStream fis =new FileInputStream(file);
		Workbook wb = WorkbookFactory.create(fis);
		Object value ="";
		Sheet sh=wb.getSheet(SheetName);
		Iterator<Row> rows = sh.rowIterator();
		while(rows.hasNext()){
			Row row = rows.next();
			Iterator<Cell> cells = row.cellIterator();
			while(cells.hasNext()){
				Cell cell = cells.next();
				CellType type = cell.getCellTypeEnum();
				if(type==CellType.STRING){
					value=cell.getRichStringCellValue();
				}
				else if(type==CellType.NUMERIC){
					value=cell.getNumericCellValue();
				}
			}
		}
		return value;
	}

	
	@Test
	public void sheetetst() throws EncryptedDocumentException, InvalidFormatException, IOException{
		Object data = ExcelSheetTest.readxl("Sheet1");
		System.out.println(data);
	}
}






