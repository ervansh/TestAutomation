package scripts;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class RobotTest {

	@Test
		public void test1() throws AWTException, InterruptedException{
		WebDriver driver=new FirefoxDriver();
		driver.get("file:///C:/Users/vanshraj.singh/Desktop/tos.html");
		
		System.out.println("abc");
		
		driver.findElement(By.id("username1")).sendKeys("mm");
		
		Robot robot=new Robot();
		
		
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		Thread.sleep(2000);
		System.out.println("yyyyy");
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_S);
		robot.keyRelease(KeyEvent.VK_S);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		
		Thread.sleep(5000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		


		
		
		

	}

}
