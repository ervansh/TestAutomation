package extentreport;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class ParallelMethodsTest extends ExtentManager{
	
	 ExtentTest test;
    private final String filePath = System.getProperty("user.dir")+"\\null\\ParallelMethodsTest.html";
    
    @BeforeSuite
    public void beforeSuite() {
        extent = ExtentManager.getReporter(filePath);
        System.out.println(System.getProperty("user.dir"));
    }
    
    @Test
    public void parallelTest01() {
        test = ExtentTestManager.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
        test.log(LogStatus.INFO, "Log from threadId: " + Thread.currentThread().getId());
        test.log(LogStatus.INFO, "Log from threadId: " + Thread.currentThread().getId());
        ExtentTestManager.endTest();
    }
    
    @Test
    public void parallelTest02() {
        test = ExtentTestManager.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
        test.log(LogStatus.ERROR, "Log from threadId: " + Thread.currentThread().getId());
        test.log(LogStatus.ERROR, "Log from threadId: " + Thread.currentThread().getId());
        ExtentTestManager.endTest();
    }
    @Test
    public void demotest(){
    	System.out.println(" demo testing");
    }
	@BeforeMethod
	public void setUp(){
		System.out.println("before method");
			}
    @AfterMethod
    public void afterEachTest(ITestResult result) {
    	test=ExtentTestManager.startTest(Thread.currentThread().getName()+" thread name");
		test.log(LogStatus.INFO, "bbb", "des");

        if (!result.isSuccess()) {
            test.log(LogStatus.FAIL, result.getThrowable());
        }
        
        extent.endTest(test);
        extent.flush();
    }


}
