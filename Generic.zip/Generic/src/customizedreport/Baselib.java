package customizedreport;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

public class Baselib {
	public static WebDriver driver;
	public String bn(){
		 Capabilities cap = ((RemoteWebDriver)driver).getCapabilities();
		 driver=new FirefoxDriver();
		 return cap.getBrowserName();
	}

}
