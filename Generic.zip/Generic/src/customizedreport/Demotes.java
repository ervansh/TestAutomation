package customizedreport;

import static org.testng.Assert.assertTrue;

import org.testng.Reporter;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners({customizedreport.TestNGCustomReportListener.class})
public class Demotes {

	
	@Test
	public void A(){
		Reporter.log("A method");
		assertTrue(true);
	}
	
	@Test
	public void B(){
		Reporter.log("B method");
		assertTrue(false);
	}
	
	@Test(dependsOnMethods={"B"})
	public void C(){
		Reporter.log("C method");
		assertTrue(true);
	}
}
