package collectionFramework;
import java.util.*;


public class ComparableInterface {
	
	public static void main(String args[]) {
		ArrayList<Student> al = new ArrayList<Student>();
		al.add(new Student(1, "vijay", 10));
		al.add(new Student(15, "Chandan", 56));
		al.add(new Student(10, "keshav", 30));
		al.add(new Student(21, "Zeeshan", 20));
		al.add(new Student(8, "Sud", 27));
		

		Collections.sort(al);
		
		for (Student student : al) {
			System.out.println(student.rollno);
			System.out.println(student.name);
			System.out.println(student.age);
		}
		
	}

}