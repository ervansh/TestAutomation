package collectionFramework;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

public class MapwithList {

	public static void main(String[] args) {

		ArrayList<String> al = new ArrayList<>();

		for (int i = 0; i < 5; i++) {
			al.add("abc" + i);
		}

		ArrayList<String> al1 = new ArrayList<>();

		for (int i = 5; i < 10; i++) {
			al1.add("abc" + i);
		}

		ArrayList<String> al2 = new ArrayList<>();

		for (int i = 10; i < 15; i++) {
			al2.add("abc" + i);
		}
		System.out.println(al);
		System.out.println(al1);
		System.out.println(al2);

		HashMap<Integer, ArrayList<String>> hm = new HashMap<>();

		hm.put(1, al);
		hm.put(2, al1);
		hm.put(3, al2);

		System.out.println(hm);
		System.out.println(hm.get(1));

		HashMap<String, Book> hm1 = new HashMap<>();

		Book b1 = new Book("Bottle", 100);
		Book b2 = new Book("Mouse", 120);

		hm1.put("fiction", b1);
		hm1.put("horror", b2);

		System.out.println(hm1);
		System.out.println(hm1.get("fiction") + " fiction");

		Set<Entry<String, Book>> es = hm1.entrySet();
		for (Entry<String, Book> entry : es) {
			System.out.println(entry.getKey());
			System.out.println(entry.getValue());
			Book v = entry.getValue();

			System.out.println(v.name);
			System.out.println(v.p);
			v.read();
		}

	}

}
