package collectionFramework;

public class Book {
String name;
int p;
	public Book(String name, int prize) {
		this.name=name;
		this.p=prize;
	}
	
	public void read() {
		System.out.println("Hello world.....");
	}
}
