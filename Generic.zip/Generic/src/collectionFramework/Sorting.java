package collectionFramework;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class Sorting {
	
public static void main(String[] args) {
	
	ArrayList<String> al=new ArrayList<String>();  
	al.add("Viru");  
	al.add("Saurav");  
	al.add("Mukesh");  
	al.add("Tahir"); 
	
	ArrayList<Integer> ali=new ArrayList<>();
	  for (int i = 10; i > 1; i--) {
		ali.add(i);
	}
	  
	  System.out.println(ali);
	  Collections.sort(ali);
	  Iterator<Integer> itra = ali.iterator();
	  while(itra.hasNext()) {
		  System.out.println(itra.next());
	  }
	  System.out.println();
	  
	Collections.sort(al);  
	Iterator<String> itr = al.iterator();  
	
	while(itr.hasNext()){  
	System.out.println(itr.next());  
	 }  
	}



	
}
