package collectionFramework;

import java.util.ArrayList;
import java.util.SortedSet;
import java.util.TreeSet;

public class ArraylistTest {

	
	public static void main(String[] args) {
		
		ArrayList<String> al1=new ArrayList<>();
		
		al1.add("C");
		al1.add("E");
		al1.add("J");
		al1.add("Z");
		al1.add("A");
		al1.add("B");
		
		System.out.println(al1.get(0));
		
		
		ArrayList<String> al2=new ArrayList<>();
		al2.add("A");
		al2.add("B");
		al2.add("C");
		al2.add("J");
		
		
		System.out.println(al1+" al1");
		System.out.println(al2+" al2");
		
		if(al1.containsAll(al2)) {
			System.out.println("hi...");
		}
		
		SortedSet<String> s=new TreeSet<>();  //sorts the values
		s.add("C");
		s.add("E");
		s.add("J");
		s.add("Z");
		s.add("A");
		s.add("B");
		System.out.println(s);
		
		SortedSet<Integer> s1=new TreeSet<>();  //sorts the values
		s1.add(9);
		s1.add(1);
		s1.add(5);
		s1.add(3);
		s1.add(3);
		
		System.out.println(s1);
	}
	
}
