package collectionFramework;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class CollectionClassTest {

	public static void main(String[] args) {
		ArrayList<Integer> alint=new ArrayList<>();
		for (int i = 0; i < 10; i++) {
			alint.add(i);
		}
		System.out.println(alint);
		System.out.println(Collections.max(alint));
		System.out.println(Collections.min(alint));
		
		
		ArrayList<String> alstr=new ArrayList<>();
		for (int i = 0; i < 10; i++) {
			alstr.add("a"+i);
		}
		System.out.println(alstr);
		System.out.println(Collections.max(alstr));
		System.out.println(Collections.min(alstr));
	
		ArrayList<String> st=new ArrayList<>();
		st.add("Abhay");
		st.add("Zombiee");
		st.add("Ballu");
		st.add("Jack");
		System.out.println(st);
		
		System.out.println(Collections.max(st));
		System.out.println(Collections.min(st));
		Collections.reverse(st);
		Iterator<String> stitr = st.iterator();
		while(stitr.hasNext()) {
			System.out.println(stitr.next());
		}
		
		Collections.swap(st, 1, 2);
		System.out.println(st);
		
	}
}












