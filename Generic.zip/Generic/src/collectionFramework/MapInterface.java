package collectionFramework;

import java.util.TreeMap;

public class MapInterface {

	public static void main(String[] args) {
		
//HashMap>>	HashMap is the implementation of Map but it doesn't maintain any insertion order.
//LinkedHashMap>>	LinkedHashMap is the implementation of Map, it inherits HashMap class. It maintains insertion order.
//TreeMap>>	TreeMap is the implementation of Map and SortedMap, it maintains ascending order.
		
		 TreeMap<Integer,String> tm=new TreeMap<Integer,String>();  
		  tm.put(100,"Amit");  
		  tm.put(102,"Ravi");  
		  tm.put(101,"Vijay");  
		  
		  tm.put(103,"v"); 
		  tm.put(103,"Rahul"); 
		 
		  System.out.println(tm.get(100));
		  
		  System.out.println(tm.keySet());
		  
		  for ( Integer ks : tm.keySet()) {
			System.out.println(tm.get(ks));
		}
		  System.out.println(tm.entrySet());
		  
		 
	}  
		
	
}
