package rough;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Test {
	
	public static void main(String[] args) {
		
		Date d=new Date();
		SimpleDateFormat ft=new SimpleDateFormat("dd/MM/yyyy");
		String f = ft.format(d);
		
		
	}

}
