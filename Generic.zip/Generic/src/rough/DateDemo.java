package rough;

public class DateDemo {

	public static void main(String[] args) {
//		// Instantiate a Date object
//		Date date =new Date();
//		// display time and date using toString()
//		System.out.println(date.toString());
//		
//		SimpleDateFormat ft = new SimpleDateFormat("E yyyy.MM.dd 'at' hh:mm:ss a zzz");//to change formate
//		String f = ft.format(date);
//		System.out.println(f);

	
		
	}

}
