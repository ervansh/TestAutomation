package rough;


public class Rough_MainMethodused {

	public static void main(String[] args) {
		String in = "This is test for copy file.";
	}

}
