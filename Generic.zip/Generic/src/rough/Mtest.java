package rough;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class Mtest {
	public static void main(String[] args) {
		

		ArrayList<Integer> al=new ArrayList<>();
		
	for(int i=0; i<10;i++){
		al.add(i);
	}
	System.out.println(al);
	
	HashMap<Integer, ArrayList<Integer>> hm= new HashMap<>();
	hm.put(1, al);
	
	System.out.println(hm);
	Set<Integer> ks = hm.keySet();
	System.out.println(ks+" keyset");
	Set<Entry<Integer, ArrayList<Integer>>> es = hm.entrySet();
	System.out.println(es + " entry set");
	
	System.out.println(hm.get(1)+" vansh");
	
	System.out.println(al+" array list");
	
	for (int i = 0; i < al.size(); i++) {
		Integer txt = al.get(i);
		System.out.println(txt);
		if(txt.toString().contains("4")){
			System.out.println("conut");
		}
	}
	
	}

}












