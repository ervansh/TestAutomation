package rough;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;

public class NewTest {
	 
  @Test
  public void f() {
	  Assert.assertTrue(true);
	  
  }
  @Test
  public void f1() {
	  
	  Assert.assertTrue(false);
  }
  @Test(dependsOnMethods= {"f1"})
  public void f2() {
	  Assert.assertTrue(true);
			 
  }
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("b m");
  }

  @AfterMethod
  public void afterMethod(ITestResult result) {
	  System.out.println("After method");
  }
}
