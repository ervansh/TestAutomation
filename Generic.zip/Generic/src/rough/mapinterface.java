package rough;

import java.util.ArrayList;
import java.util.HashMap;

public class mapinterface {

	public static void main(String[] args) {
		test();
		

	}

	public static void test() {
		System.out.println(" abc");

		ArrayList<String> al = new ArrayList<>();
		HashMap<Integer, ArrayList<String>> map = new HashMap<>();

		for (int i = 0; i < 10; i++) {
			al.add("data" + i);
			map.put(i, al);
		}

		System.out.println(al+"  data in al.");
		
		ArrayList<String> mapdata = map.get(1);
		System.out.println(mapdata+"   map data in form of al");
		
		for(String data:mapdata){
			System.out.println(data+"  al data");
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
