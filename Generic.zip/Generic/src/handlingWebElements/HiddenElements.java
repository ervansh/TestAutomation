package handlingWebElements;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class HiddenElements {

	public static void main(String[] args) {
		
		//using java script executor we can handle it
		System.setProperty("webdriver.gecko.driver", "D:\\Software\\drivers\\geckodriver-v0.21.0-win64\\geckodriver.exe");
		WebDriver d=new FirefoxDriver();
		
		
		JavascriptExecutor je = (JavascriptExecutor)d;
		je.executeScript("document.getElementByClassName(elementlocator).click();");  //it will click on the hidden element.
		
	}
}
