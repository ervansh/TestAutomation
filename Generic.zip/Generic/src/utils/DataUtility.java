package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;


/**
 * @author vanshraj.singh
 * @description 
 */
public class DataUtility {
	

	public static void putData() throws EncryptedDocumentException, InvalidFormatException, IOException {
		
		System.out.println("put data method");
		
		String filepath=".\\test-data\\test.xlsx";
		
		File file=new File(filepath);
		
		FileInputStream fis = new FileInputStream(file);
			
			Workbook wb = WorkbookFactory.create(fis);
			
			System.out.println("workbook created");
			Sheet sheet = wb.getSheetAt(0);
			Row row = sheet.getRow(0);
			Cell cell = row.getCell(3);
			
			if(cell==null) {
				cell=row.createCell(3);
				cell.setCellType(CellType.STRING);
				cell.setCellValue("vanshraj singh");
				System.out.println("Value has been written");
				
			}
			else if(cell!=null) {
				cell.setCellValue("lokesh");
				System.out.println("Value has been written");
			}
			
			FileOutputStream fos = new FileOutputStream(".\\test-data\\test.xlsx");
			wb.write(fos);
			fos.close();
			
	}
	
	
		
	}
	
	

