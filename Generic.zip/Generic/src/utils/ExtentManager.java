package utils;

import java.io.File;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.NetworkMode;

public class ExtentManager {
	
	private static ExtentReports extent;
	public synchronized static ExtentReports getReporter(String setfilepath)
	{
		if(extent==null)
		{
			extent = new ExtentReports(setfilepath, NetworkMode.OFFLINE);
			String xmlfilepath = ".\\test_data\\extent-config.xml";
            extent.loadConfig(new File(xmlfilepath));
			extent.addSystemInfo("Selenium version", "2.53.1")
			.addSystemInfo("Environment", "QA");
			
		}
		
		return extent;
	}
	public static Object getTest() {
		// TODO Auto-generated method stub
		return null;
	}

}
