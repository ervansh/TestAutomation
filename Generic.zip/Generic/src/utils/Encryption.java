package utils;

import org.apache.commons.codec.binary.Base64;

public class Encryption {
	public static String encryptData(String dataToBeEncrypted){
		byte[] encodedbyte = Base64.encodeBase64(dataToBeEncrypted.getBytes());
		String encrypted = new String(encodedbyte);
		return encrypted;
	}

}
