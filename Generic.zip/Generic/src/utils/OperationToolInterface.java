package utils;

public interface OperationToolInterface {
	
	void addMasters();
	void update();
	void delete();
	

}
