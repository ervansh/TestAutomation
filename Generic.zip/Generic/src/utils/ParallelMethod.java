package utils;



public class ParallelMethod {
	/*<?xml version="1.0" encoding="UTF-8"?>
<suite name="Extent Parallel Test" parallel="methods">
    <test name="ExtentWithParallelMethods" allow-return-values="true">
        <classes>
            <class name="ParallelMethodsTest" />
        </classes>
    </test>
</suite>

	@Test
public class ParallelMethodsTest {
    private final String filePath = "ParallelMethodsTest.html";
    
    @BeforeSuite
    public void beforeSuite() {
        extent = ExtentManager.getReporter(filePath);
    }
    
    @Test
    public void parallelTest01() {
        ExtentTest test = ExtentTestManager.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
        test.log(LogStatus.INFO, "Log from threadId: " + Thread.currentThread().getId());
        test.log(LogStatus.INFO, "Log from threadId: " + Thread.currentThread().getId());
        ExtentTestManager.endTest();
    }
    
    @Test
    public void parallelTest02() {
        ExtentTest test = ExtentTestManager.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
        test.log(LogStatus.ERROR, "Log from threadId: " + Thread.currentThread().getId());
        test.log(LogStatus.ERROR, "Log from threadId: " + Thread.currentThread().getId());
        ExtentTestManager.endTest();
    }
	
    @AfterMethod
    public void afterEachTest(ITestResult result) {
        if (!result.isSuccess()) {
            test.log(LogStatus.FAIL, result.getThrowable());
        }
        
        extent.endTest(test);
        extent.flush();
    }
}

public class ExtentTestManager {  // new
    static Map extentTestMap = new HashMap();
    private static ExtentReports extent = ExtentManager.getReporter();

    public static synchronized ExtentTest getTest() {
        return extentTestMap.get((int) (long) (Thread.currentThread().getId()));
    }

    public static synchronized void endTest() {
        extent.endTest(extentTestMap.get((int) (long) (Thread.currentThread().getId())));
    }

    public static synchronized ExtentTest startTest(String testName) {
        return startTest(testName, "");
    }

    public static synchronized ExtentTest startTest(String testName, String desc) {
        ExtentTest test = extent.startTest(testName, desc);
        extentTestMap.put((int) (long) (Thread.currentThread().getId()), test);

        return test;
    }
}

public class ExtentManager {
    private static ExtentReports extent;
    
    public synchronized static ExtentReports getReporter(String filePath) {
        if (extent == null) {
            extent = new ExtentReports(filePath, true, NetworkMode.ONLINE);
            
            extent
                .addSystemInfo("Host Name", "Anshoo")
                .addSystemInfo("Environment", "QA");
        }
        
        return extent;
    }
    
    public synchronized static ExtentReports getReporter() {
        return extent;
    }
}


*/}