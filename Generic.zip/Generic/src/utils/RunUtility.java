package utils;

import java.util.ArrayList;
import java.util.List;

import org.testng.TestNG;
import org.testng.annotations.Test;

public class RunUtility {
	TestNG testng = new TestNG();
	List<String> files = new ArrayList<>();
	
	//runs test using all suite files
	@Test
	public void runSuites() {
		
		files.add("./suite-files/LoginTest.xml");
		files.add("./suite-files/MachineMastersTest.xml");
		testng.setTestSuites(files);
		testng.run();
	}
	
	//runs test using all classes
	@Test(enabled=false)
	public void runClasses() {
		//testng.setTestClasses(new Class[] {LoginTest.class, MachineMastersTest.class});
		testng.run();
	}

}
