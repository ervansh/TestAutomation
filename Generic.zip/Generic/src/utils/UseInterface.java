package utils;

public class UseInterface implements OperationToolInterface{
	public static void main(String[] args) {
		UseInterface inp=new UseInterface();
		inp.addMasters();
	}

	@Override
	public void addMasters() {
	}

	@Override
	public void update() {
	}

	@Override
	public void delete() {
	}

}
