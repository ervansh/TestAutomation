package utils;

public class BaseLib {
	public BaseLib() {
	}

}
