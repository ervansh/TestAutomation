package utils;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class ExtentExample {
	WebDriver driver;
	ExtentReports report;
	ExtentTest test;
	
	@Test
	public void example()
	{
		report = new ExtentReports("D:\\Vanshraj.Singh\\Reports\\TOS Standard\\ExtentReports\\exam.html");
		
		test = report.startTest("example");
		
		test.log(LogStatus.INFO, "test started");
		
		test.log(LogStatus.PASS, "test passed");
		
		report.endTest(test);
		
		report.flush();
	
	}

}
