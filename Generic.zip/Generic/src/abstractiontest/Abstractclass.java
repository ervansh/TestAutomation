package abstractiontest;

public abstract class Abstractclass {
	
	abstract void atest();
	public void btest(){
		System.out.println("b test");
	}
	abstract void ctest();

}
