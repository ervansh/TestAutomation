package abstractiontest;

public class AbstractTest extends Abstractclass{

	@Override
	void atest() {
		System.out.println("a test");
	}
	@Override
	void ctest() {
		System.out.println("c test");
	}
	public void dtest(){
		System.out.println("d test");
	}
	public static void main(String[] args) {
		Abstractclass abc=new Abstractclass() {
			
			@Override
			void ctest() {
				System.out.println("c is overriden");
			}
			
			@Override
			void atest() {
				System.out.println("a is overriden");
			}
		};
		abc.atest();
		abc.btest();
		abc.ctest();
	}
}
