package abstractiontest;

public class Abstract_Test {

	public static void main(String[] args) {
		AbstractTest ab=new AbstractTest();
		ab.atest();
		
	}
}
