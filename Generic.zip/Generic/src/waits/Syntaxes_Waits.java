package waits;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Syntaxes_Waits {

	public static WebDriver driver;
	public static void main(String[] args) {
		//implicite wait
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		
		//explicit wait
		WebDriverWait wdw = new WebDriverWait(driver, 20);
		WebElement ele=driver.findElement(By.id(""));
		wdw.until(ExpectedConditions.visibilityOf(ele));
		
		
	}
}
