package erParallelClasses;

import com.relevantcodes.extentreports.ExtentReports;

public class Ereport {

    static ExtentReports extent;
    final static String filePath = "Extent.html";
    
    public synchronized static ExtentReports getReporter() {
        if (extent == null) {
            extent = new ExtentReports(filePath, true);
        }
        
        return extent;
    }


}
