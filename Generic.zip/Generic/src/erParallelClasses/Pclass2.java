package erParallelClasses;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import extentreport.ExtentTestManager;

public class Pclass2 {
	
	@Test
    public void parallelClass2TestResultMustEqualFail() throws Exception {
        ExtentTestManager.getTest().log(LogStatus.FAIL, "Log from threadId: " + Thread.currentThread().getId());
        ExtentTestManager.getTest().log(LogStatus.INFO, "Log from threadId: " + Thread.currentThread().getId());
        
        throw new Exception("intentional failure");
    }


}
