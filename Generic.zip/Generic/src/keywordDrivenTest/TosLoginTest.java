package keywordDrivenTest;

import java.io.IOException;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
public class TosLoginTest {
	private RespositoryParser_SwitchCase parser;
	private WebDriver driver;
	@BeforeClass
	public void setUp() throws IOException
	{
		driver = new FirefoxDriver();
		driver.get(ReadPropFile.readProp("url"));
		parser = new RespositoryParser_SwitchCase(".\\mySpace\\keywordDrivenTest\\ore.properties");
	}
	@Test(enabled=false)                       //switch case is used in this Object repository                            
	public void logintos_switchRepo() throws InterruptedException
	{
		//Lets see how we can find the first name field
		WebElement username = driver.findElement(parser.getObjectLocator("UN"));
		WebElement pass = driver.findElement(parser.getObjectLocator("pass"));
		WebElement btnlogin = driver.findElement(parser.getObjectLocator("btnLogin"));
		System.out.println(username+" hey its working");
		username.sendKeys("Administrator");
		pass.sendKeys("savior@1");
		btnlogin.click();
	}

	@Test()                  //if-else-if case is used in this Object repository
	public void logintos_elseifRepo()
	{
		try{
		ObjectMap_if_else oMap=new ObjectMap_if_else(".\\mySpace\\keywordDrivenTest\\ore.properties");
		WebElement un = driver.findElement(oMap.getLocator("UN"));
		WebElement pwd = driver.findElement(oMap.getLocator("pass"));
		WebElement btnl = driver.findElement(oMap.getLocator("btnLogin"));
		System.out.println(un +"else if map");
		un.sendKeys("Administrator");
		pwd.sendKeys("savior@1");
		btnl.click();
		
		Thread.sleep(3000);
		 Set<String> window = driver.getWindowHandles();
		 Iterator<String> it = window.iterator();
		 it.next();
		 String child=it.next();
		 driver.switchTo().window(child);
		 driver.switchTo().alert().accept();
		 driver.manage().window().maximize();
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
		
		}
		catch(Exception e){
			String v = e.getMessage();
			System.out.println("Error with getMessage method is :\n"+v);
			System.out.println("using toString method: Error during test execution:\n" + e.toString());
		}
	}
	@AfterClass
	public void tearDown()
	{
		//driver.quit();
	}
}
