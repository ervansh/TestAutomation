package keywordDrivenTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ReadPropFile {
	
	public static String readProp(String Key) throws IOException{
		
		FileInputStream fis=new FileInputStream(new File(".\\mySpace\\keywordDrivenTest\\general.properties"));
		
		Properties prop=new Properties();
		prop.load(fis);
		
		System.out.println(prop.getProperty("url"));
		String value = prop.getProperty(Key);
		
		return value;

	}
}
